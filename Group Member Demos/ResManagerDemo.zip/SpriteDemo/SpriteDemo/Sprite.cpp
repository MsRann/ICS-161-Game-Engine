// TODO: code this
#include "Sprite.h"
#include <string>

void renderTexture(SDL_Texture *tex, SDL_Renderer *ren, SDL_Rect dst, SDL_Rect *clip);
void renderTexture(SDL_Texture *tex, SDL_Renderer *ren, int x, int y, SDL_Rect *clip);

Sprite::Sprite(int width, int height, SDL_Renderer* ren){
	Sprite::width = width;
	Sprite::height = height;
	renderer = ren;
	index = 0;

	boundary = nullptr;
}

Sprite::Sprite(int width, int height, SDL_Renderer* ren, SDL_Rect* bound) {
	Sprite::width = width;
	Sprite::height = height;
	renderer = ren;
	index = 0;
	
	boundary = bound;
}

Sprite::~Sprite(void) {

}

void Sprite::setPos(int x, int y) {
	currX = x;
	currY = y;
}

void Sprite::movex(int delta) {
	currX = currX + delta;
}

void Sprite::movey(int delta) {
	currY = currY + delta;
}

int Sprite::getX() {
	return currX;
}

int Sprite::getY() {
	return currY;
}

int Sprite::makeFrame(SDL_Texture* texture, int x, int y) {
	frame f;
	f.texture = texture;
	f.x = x;
	f.y = y;
	frames.push_back(f);
	return index++;
}

int Sprite::addFrameToSequence(std::string seqName, int frameIndex) {
	sequenceList[seqName].push_back(frameIndex);
	return sequenceList.size();
}

void Sprite::show(int frameIndex) {
	SDL_Rect r;
	r.x = frames[frameIndex].x;
	r.y = frames[frameIndex].y;
	r.w = width;
	r.h = height;
	checkBounds();
	renderTexture(frames[frameIndex].texture, renderer, getX(), getY(), &r);
}

void Sprite::show(std::string sequence) {
	//show(0);
	if ((unsigned) sequenceIndex < sequenceList[sequence].size()) {
		show(sequenceList[sequence][sequenceIndex]);
		sequenceIndex++;
	}
	else {
		sequenceIndex = 0;
		show(sequenceList[sequence][sequenceIndex]);
	}
}

void Sprite::checkBounds() {
	if (boundary != nullptr) {
		if (currX < boundary->x) currX = boundary->x;
		if (currX + width > boundary->x + boundary->w) currX = boundary->x + boundary->w - width;
		if (currY < boundary->y) currY = boundary->y;
		if (currY + height > boundary->y + boundary->h) currY = boundary->y + boundary->h - height;
	}
}

/**
* Draw an SDL_Texture to an SDL_Renderer at some destination rect
* taking a clip of the texture if desired
* @param tex The source texture we want to draw
* @param ren The renderer we want to draw to
* @param dst The destination rectangle to render the texture to
* @param clip The sub-section of the texture to draw (clipping rect)
*		default of nullptr draws the entire texture
*/
void renderTexture(SDL_Texture *tex, SDL_Renderer *ren, SDL_Rect dst, SDL_Rect *clip = nullptr){
	SDL_RenderCopy(ren, tex, clip, &dst);
}

/**
* Draw an SDL_Texture to an SDL_Renderer at position x, y, preserving
* the texture's width and height and taking a clip of the texture if desired
* If a clip is passed, the clip's width and height will be used instead of
*	the texture's
* @param tex The source texture we want to draw
* @param ren The renderer we want to draw to
* @param x The x coordinate to draw to
* @param y The y coordinate to draw to
* @param clip The sub-section of the texture to draw (clipping rect)
*		default of nullptr draws the entire texture
*/
void renderTexture(SDL_Texture *tex, SDL_Renderer *ren, int x, int y, SDL_Rect *clip = nullptr){
	SDL_Rect dst;
	dst.x = x;
	dst.y = y;
	if (clip != nullptr){
		dst.w = clip->w;
		dst.h = clip->h;
	}
	else {
		SDL_QueryTexture(tex, NULL, NULL, &dst.w, &dst.h);
	}
	renderTexture(tex, ren, dst, clip);
}