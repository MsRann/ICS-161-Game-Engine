#include "Background.h"
#include "Scientist.h"

#include <Windows.h>
#include "SDL_image.h"
#include "SDL.h"
#include "cleanup.h"


#include <string>
#include <iostream>
#include <sstream>

const int SCREEN_WIDTH = 640;
const int SCREEN_HEIGHT = 480;

int main(int argc, char **argv){

	//Initializes everything and errors if failure
	if (SDL_Init(SDL_INIT_EVERYTHING) != 0){
		std::cout << "SDL_Init Error: " << SDL_GetError() << std::endl;
		return 1;
	}
	//Initializes image stuff? Quits if failure
	if ((IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG) != IMG_INIT_PNG){
		SDL_Quit();
		return 1;
	}

	//Creates a window
	SDL_Window *window = SDL_CreateWindow("Game Demo", 800, 100, SCREEN_WIDTH,
		SCREEN_HEIGHT, SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);
	if (window == nullptr){
		SDL_Quit();
		return 1;
	}

	//Creates renderer
	SDL_Renderer *renderer = SDL_CreateRenderer(window, -1,
		SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
	if (renderer == nullptr){
		//cleanup(window);
		SDL_Quit();
		return 1;
	}

	std::string spritesheetLocation = "C:\\Users\\Jake\\Desktop\\SDL\\MyProjects\\res\\GameTest\\Trainers.png";

	
	SDL_Surface* spritesheetTestSurface = IMG_Load(spritesheetLocation.c_str());
	SDL_SetColorKey(spritesheetTestSurface, 1, SDL_MapRGB(spritesheetTestSurface->format, 255, 255, 255));
	SDL_Texture *spritesheetTest = SDL_CreateTextureFromSurface(renderer, spritesheetTestSurface);
	//SDL_Texture *spritesheetTest = IMG_LoadTexture(renderer, spritesheetLocation.c_str());

	if (spritesheetTest == nullptr){
		//cleanup(spritesheetTest, renderer, window);
		IMG_Quit();
		SDL_Quit();
		return 1;
	}

	//Initial setup to show the background before input is even collected
	Background image = Background("static_map.png", SCREEN_WIDTH, SCREEN_HEIGHT, renderer);
	image.renderBackground();

	Scientist Joe = Scientist(spritesheetTest, renderer, 200, 100);
	Scientist Frank = Scientist(spritesheetTest, renderer, 100, 100);


	SDL_RenderPresent(renderer);

	SDL_Event e;
	bool quit = false;
	std::string spriteDirection = "walk up";
	bool isPressed = false; //Will let renderScientist know if it should be in idle or moving.
	
	Joe.renderScientist(spriteDirection, false);


	while (!quit){
		while (SDL_PollEvent(&e)){
			if (e.type == SDL_QUIT){
				quit = true;
			}
			isPressed = false; // resets
			if (e.type == SDL_KEYDOWN){
				if (e.key.keysym.sym == SDLK_RIGHT)
				{
					isPressed = true;
					spriteDirection = "walk right";
				}
				else if (e.key.keysym.sym == SDLK_LEFT)
				{
					isPressed = true;
					spriteDirection = "walk left";
				}
				else if (e.key.keysym.sym == SDLK_UP)
				{
					image.changeBackground("static_map.png");
					image.renderBackground();
					isPressed = true;
					spriteDirection = "walk up";
				}
				else if (e.key.keysym.sym == SDLK_DOWN)
				{
					image.changeBackground("BowsersCastle.png");
					image.renderBackground();
					isPressed = true;
					spriteDirection = "walk down";
				}

			}
		}

		// Clear the scene, Render the scene
		SDL_RenderClear(renderer);
		image.renderBackground();
		Joe.renderScientist(spriteDirection , isPressed);
		Frank.renderScientist("walk down", false);
		SDL_RenderPresent(renderer);
		
	}

	
	IMG_Quit();


	SDL_Quit();

	return 0;
}