#include "Sprite.h"
#include <iostream>
#include <SDL_image.h>
#include <string>
//#include <res_path.h>

Sprite::Sprite(int width, int height, SDL_Renderer* ren)
	:width(width), height(height), renderer(ren){}

void Sprite::setPos(int x, int y)
{
	currX = x;
	currY = y;
}

void Sprite::movex(int delta)//, Sprite other, bool isBoundary)
{
	//if (checkCollision() != true){
	//	currX += delta;
	//}
	currX += delta;
}

void Sprite::movey(int delta)//, Sprite other)
{
	//if (checkCollision() != true){
	//	currY += delta;
	//}
	currY += delta;
}

int Sprite::getX(){
	return currX;
}
int Sprite::getY(){
	return currY;
}

// makeFrame returns the unique index of the frame
int Sprite::makeFrame(SDL_Texture* texture, int x, int y, double frameTimeLength)
{
	frame addedFrame;// (texture, x, y);
	addedFrame.texture = texture;
	addedFrame.x = x;
	addedFrame.y = y;
	addedFrame.timeLength = frameTimeLength;
	frames.push_back(addedFrame);
	return frames.size()-1;
}


// addFrameToSequence returns the number of frames in the sequence after the add
int Sprite::addFrameToSequence(std::string seqName, int frameIndex)
{
	sequenceList[seqName].push_back(frameIndex);
	return sequenceList.size()-1;
}

// show(int) renders the frame with the specified frameIndex
void Sprite::show(int frameIndex)
{
	SDL_Rect dst;
	SDL_Rect clip;

	dst.x = currX;
	dst.y = currY;
	dst.w = width;
	dst.h = height;

	clip.x = frames[frameIndex].x;
	clip.y = frames[frameIndex].y;
	clip.w = width;
	clip.h = height;

	
	
	SDL_RenderCopy(renderer, frames[frameIndex].texture, &clip, &dst);
	//getchar();
}

// show(string) cycles through all frames in the specified sequence, one per call
void Sprite::show(std::string sequence)
{
	//std::cout << sequence << std::endl;
	
	
	if (sequence != prevSequence){
		timePrev = std::chrono::high_resolution_clock::now();
	}
	prevSequence = sequence;
	
	if (frames[sequenceList.at(sequence)[sequenceIndex]].timeLength != 0){

		//For debugging purposes
		double diff = GetTimeDifference();
		//std::cout << diff << std::endl;

		//If the timeLength == 0.0 then it is never supposed to change
		//If the timer for the frame has been reached, advance to the next frame in the sequence
		//	If reached just passed the end of the sequence, set the sequence index back to 0
		if (diff >= frames[sequenceList.at(sequence)[sequenceIndex]].timeLength){
			std::cout << diff << std::endl;
			sequenceIndex++;
			if (sequenceIndex >= sequenceList.at(sequence).size()){
				sequenceIndex = 0;
			}
			timePrev = std::chrono::high_resolution_clock::now();
		}
		if (sequenceIndex >= sequenceList.at(sequence).size()){
			sequenceIndex = 0;
		}
	}
	show(sequenceList.at(sequence)[sequenceIndex]);

}

double Sprite::GetTimeDifference(){
	// Get current time as a std::chrono::time_point
	// which basically contains info about the current point in time
	auto timeCurrent = std::chrono::high_resolution_clock::now();

	// Compare the two to create time_point containing delta time in nanosecnds
	auto timeDiff = std::chrono::duration_cast<std::chrono::nanoseconds>(timeCurrent - timePrev);

	// Get the tics as a variable
	double delta = timeDiff.count();

	// Turn nanoseconds into seconds
	delta /= 1000000000;

	//timePrev = timeCurrent;
	return delta;
}

//bool Sprite::checkCollision(){} //Added for the homework